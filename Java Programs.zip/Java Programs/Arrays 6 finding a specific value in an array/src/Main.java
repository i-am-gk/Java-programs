import java.util.Scanner;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		int [] array = new int [5];
		int value;
		System.out.println("Enter value to check ");
		value=scanner.nextInt();
		System.out.println("Input 5 positive numbers");
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter value "+(i+1));
			array[i]=scanner.nextInt();
		}
		System.out.println("Values are ");
		for(int i=0;i<5;i++)
		{
			System.out.println("Index " +i+ " Value "+array[i]);
		}
			
	for(int i=0;i<5;i++)
	{
		if(value==array[i])
		{
			System.out.println("Value "+value+" found at index "+i);
		}
	}
	}
}


