import java.util.Scanner;

public class LetterOccurrences {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine().toLowerCase(); // Convert to lowercase for case-insensitive counting
  
        int[] counts = new int[26]; // Array to store letter counts
        
        // Iterate through each character in the input string
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (Character.isLetter(c)) { // Check if the character is a letter
                int index = c - 'a'; // Calculate the index (0-25) for the letter
                counts[index]++; // Increment the count for that letter
            }
        }
        
        // Display the letter counts
        for (int i = 0; i < 26; i++) {
            char letter = (char) ('a' + i); // Convert the index back to a letter
            System.out.println(letter + ": " + counts[i]);
        }
        
        scanner.close();
	}

}
