public abstract class Employee1 {
    private final String firstName;
    private final String lastName;
    private final String socialSecurityNumber;
    private final Date birthDate;

    public Employee1(String firstName, String lastName, String socialSecurityNumber, Date birthDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
        this.birthDate = birthDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public abstract double earnings();

    public boolean isBirthdayMonth() {
        int currentMonth = 12; // Placeholder for the current processing month
        return currentMonth == birthDate.getMonth();
    }

    @Override
    public String toString() {
        return String.format("%s %s%nSocial Security Number: %s%nBirthdate: %s",
                getFirstName(), getLastName(), getSocialSecurityNumber(), getBirthDate());
    }
}
