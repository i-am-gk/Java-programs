
public abstract class Employee {
private final String firstName;
private final String LastName;
private final String socialSecurityNumber;
// constructor
public Employee(String firstName,String LastName,String socialSecurityNumber){
	this.firstName=firstName;
	this.LastName=LastName;
	this.socialSecurityNumber=socialSecurityNumber;
}
public String getFirstName() {
	return firstName;
}
public String getLastName() {
	return LastName;
}
public String getSocialSecurityNumber() {
	return socialSecurityNumber;
}
public String toString() {
	return String.format("%s %s%nsocial security number: %s",getFirstName(),
			getLastName(),getSocialSecurityNumber());
}
// Abstract Method
	public abstract double earnings();

}
