// PayrollSystemTest class
public class PayrollSystemTest {
    public static void main(String[] args) {
        Date johnBirthday = new Date(5, 15, 1990); // Example birthday for John
        Date karenBirthday = new Date(8, 10, 1985); // Example birthday for Karen

        SalariedEmployee salariedEmployee = new SalariedEmployee("John", "Smith", "111-11-1111", johnBirthday, 800.00);
        HourlyEmployee hourlyEmployee = new HourlyEmployee("Karen", "Price", "222-22-2222", karenBirthday, 16.75, 40);

        // Create an array of Employee variables
        Employee[] employees = {salariedEmployee, hourlyEmployee};

        System.out.println("Employees processed individually:");

        for (Employee currentEmployee : employees) {
            System.out.println(currentEmployee);

            if (currentEmployee.isBirthdayMonth()) {
                System.out.println("Happy Birthday! You've earned a $100.00 bonus!");
                System.out.printf("Earned $%,.2f%n%n", currentEmployee.earnings() + 100.00);
            } else {
                System.out.printf("Earned $%,.2f%n%n", currentEmployee.earnings());
            }
        }
    }
}
