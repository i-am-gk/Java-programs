public class Class1 {
private int age;
private String name;
public void Info() {
	System.out.println("Here is the student info");
}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
}