
public class Class2 {

	public static void main(String[] args) {
	Class1 obj=new Class1();
obj.setAge(19);
obj.setName("GK");
obj.Info();
System.out.println("Name is "+obj.getName());
System.out.println("Age is "+obj.getAge());

	}

}
