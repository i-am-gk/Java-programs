
public class Main {
public void display ()
{
	System.out.println("Method with no parameter");
	
}
public void display1(int a)
{
	
	System.out.println("Method with  parameter"+a);
}
public static void main(String args [])

{
	Main obj=new Main();
	obj.display();
	obj.display1(24);
}
}
