
public class Distance {
	private int feet;
    private int inches;
    // No-argument constructor
    public Distance() {
        this.feet = 0;
        this.inches = 0;
    }
    // Two-argument constructor
    public Distance(int feet, int inches) {
        this.feet = feet;
        this.inches = inches;
    }
    // Getter for feet
    public int getFeet() {
        return feet;
    }
    // Setter for feet
    public void setFeet(int feet) {
        this.feet = feet;
    }
    // Getter for inches
    public int getInches() {
        return inches;
    }
    // Setter for inches
    public void setInches(int inches) {
        this.inches = inches;
    }

    // Display method
    public void display() {
        System.out.println(feet + " feet " + inches + " inches");
    }

    // Method to add two Distance objects and return the added Distance object
    public Distance sumDistance(Distance otherDistance) {
        int newFeet = feet + otherDistance.feet;
        int newInches =inches + otherDistance.inches;
        if (newInches >= 12) {
            newFeet += newInches / 12;
            newInches = newInches % 12;
        }
        return new Distance(newFeet, newInches);
    }

}
