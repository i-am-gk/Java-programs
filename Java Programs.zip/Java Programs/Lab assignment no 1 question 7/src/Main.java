public class Main {
	public static void main(String[] args) {
        Distance distance1 = new Distance(3, 9);
        Distance distance2 = new Distance(6, 3);
        // Display the original distances
        System.out.print("Distance 1: ");
        distance1.display();
        System.out.print("Distance 2: ");
        distance2.display();
        // Add the distances
        Distance sumDistance = distance1.sumDistance(distance2);
        // Display the sum of distances
        System.out.print("Sum of Distances: ");
        sumDistance.display();
    }
}
