
public class Main {
	public static void main(String[] args) {
        Rectangle rectangle = new Rectangle();

        // Set length and width
        rectangle.setLength(5.0);
        rectangle.setWidth(3.0);

        // Calculate and display perimeter and area
        System.out.println("Rectangle Perimeter: " + rectangle.calculatePerimeter());
        System.out.println("Rectangle Area: " + rectangle.calculateArea());

        // Try setting invalid values
        rectangle.setLength(25.0);
        rectangle.setWidth(-2.0);

        // Display updated values
        System.out.println("Updated Rectangle Length: " + rectangle.getLength());
        System.out.println("Updated Rectangle Width: " + rectangle.getWidth());
    }
}
