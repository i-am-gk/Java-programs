
public class Rectangle {
	private double length;
    private double width;

    // Constructor with default values
    public Rectangle() {
        length = 1.0;
        width = 1.0;
    }

    // Member function to calculate perimeter
    public double calculatePerimeter() {
        return 2 * (length + width);
    }

    // Member function to calculate area
    public double calculateArea() {
        return length * width;
    }

    // Setter method for length with input validation
    public void setLength(double length) {
        if (length > 0.0 && length < 20.0) {
            this.length = length;
        } else {
            System.out.println("Invalid length value. Length should be between 0.0 and 20.0.");
        }
    }

    // Getter method for length
    public double getLength() {
        return length;
    }

    // Setter method for width with input validation
    public void setWidth(double width) {
        if (width > 0.0 && width < 20.0) {
            this.width = width;
        } else {
            System.out.println("Invalid width value. Width should be between 0.0 and 20.0.");
        }
    }

    // Getter method for width
    public double getWidth() {
        return width;
    }
}
