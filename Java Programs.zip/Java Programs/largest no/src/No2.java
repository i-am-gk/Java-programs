
public class No2 {
	  public int findLargest(int a, int b, int c) { // Corrected method name
	        int largest = a;
	        if (b > largest) {
	            largest = b;
	        }
	        if (c > largest) {
	            largest = c;
	        }
	        return largest; // Moved return statement here
	    }
}
