import java.util.Scanner;
public class Largest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n1, n2, n3;
        Scanner inp = new Scanner(System.in);
        No2 a = new No2(); // Corrected class name to match Java conventions
        System.out.println("Input no 1");
        n1 = inp.nextInt();
        System.out.println("Input no 2");
        n2 = inp.nextInt();
        System.out.println("Input no 3");
        n3 = inp.nextInt();
        //int largest = a.findLargest(n1, n2, n3); // Corrected method name
        System.out.println("Largest no is " +a.findLargest(n1, n2, n3));
         
    
}
}