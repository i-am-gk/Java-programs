// Subclass 1 - RegularEmployee
class RegularEmployee extends Employee {
    double monthlySalary;
    // Constructor
    RegularEmployee(int employeeId, String name, double monthlySalary) {
        super(employeeId, name);
        this.monthlySalary = monthlySalary;
    }
    // Override calculateSalary method
    @Override
    double calculateSalary() {
        return monthlySalary;
    }
}