// Subclass 2 - Contractor
class Contractor extends Employee {
    double hourlyRate;
    // Constructor
    Contractor(int employeeId, String name, double hourlyRate) {
        super(employeeId, name);
        this.hourlyRate = hourlyRate;
    }
    // Override calculateSalary method
    @Override
    double calculateSalary() {
        // Implement salary calculation for contractors (sample logic)
        // Assuming a fixed number of hours worked for simplicity
    int hoursWorked = 96; //32 hours per week for 3 weeks
    return hourlyRate * hoursWorked;
    }
}
// Interface - Payable
interface Payable {
    double calculateNetPay(double grossSalary);
}