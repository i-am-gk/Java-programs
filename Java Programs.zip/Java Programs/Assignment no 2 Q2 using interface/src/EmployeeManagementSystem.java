import java.util.ArrayList;
public class EmployeeManagementSystem {
    public static void main(String[] args) {
        // Create instances of RegularEmployee and Contractor
        RegularEmployee regularEmployee = new RegularEmployee(881, "GK", 8000.4);
        Contractor contractor = new Contractor(764, "XYZ", 14.5);
        // Create a list of employees
        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(regularEmployee);
        employees.add(contractor);
        // Calculate and display salary for each employee
        for (Employee employee : employees) {
            double grossSalary = employee.calculateSalary();
 System.out.println("Employee ID: " + employee.getEmployeeId() + ", Name: " 
 + employee.getName() + ", Gross Salary: $" + grossSalary);
            // Calculate and display net pay for employees who implement the Payable interface
            if (employee instanceof Payable) {
                Payable payableEmployee = (Payable) employee;
                double netPay = payableEmployee.calculateNetPay(grossSalary);
                System.out.println("Net Pay: $" + netPay);
            }
            System.out.println(); // Add a line break for better readability
        }
    }
}