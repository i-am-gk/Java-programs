// Implementation of Payable interface
class Payroll implements Payable {
    // Method to calculate net pay for an employee
    @Override
    public double calculateNetPay(double grossSalary) {
        // Implement net pay calculation logic (sample logic)
        double taxRate = 0.2; // 20% tax rate for simplicity
        return grossSalary * (1 - taxRate);
    }
}
