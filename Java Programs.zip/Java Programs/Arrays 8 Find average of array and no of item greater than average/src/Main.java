import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
int [] array = new int [10];
double sum=0;
System.out.println("Enter values");
for(int i=0;i<array.length;i++)
{
	System.out.println("Value "+(i+1));
	array[i]=scanner.nextInt();
	sum+=array[i];
}
System.out.println("Sum is "+sum);
double avg=sum/10;
System.out.println("Average is "+avg);
int no=0;
for(int i=0;i<array.length;i++)
{
	if(array[i]>avg)
	{
		no++;
	}
}
System.out.println("Numbers greater than average are "+no);
	}

}
