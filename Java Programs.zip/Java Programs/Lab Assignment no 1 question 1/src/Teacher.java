public class Teacher {
	private String name;
    private int experience;
    public Teacher(String name, int experience) {
        this.name = name;
        this.experience = experience;
    }
    public void compareExp(Teacher otherTeacher) {
    	
        if (experience > otherTeacher.experience) {
        	
          System.out.println(name + " is more experienced than " + otherTeacher.name);
        } 
        else if (experience < otherTeacher.experience) {
        	
           System.out.println(name + " is less experienced than " + otherTeacher.name);
        }
        else {
        	
            System.out.println(name + " has the same experience as " + otherTeacher.name);
        }
    }
}
