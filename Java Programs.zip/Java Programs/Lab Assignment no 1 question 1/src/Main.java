
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Teacher teacher1 = new Teacher("Imran", 8);
        Teacher teacher2 = new Teacher("Ahmed", 3);
        teacher1.compareExp(teacher2);
        }
}
