public class Mathematics {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Mathematics functions");
System.out.println("Ceil Values");
System.out.println(Math.ceil(2.7));
System.out.println(Math.ceil(2.3));
System.out.println(Math.ceil(-3.4));
System.out.println(Math.ceil(-3.7));
System.out.println(Math.ceil(3.0));
System.out.println(Math.ceil(-4.0));
System.out.println("Now floor values");
System.out.println(Math.floor(2.7));
System.out.println(Math.floor(2.3));
System.out.println(Math.floor(-3.4));
System.out.println(Math.floor(-3.7));
System.out.println(Math.floor(3.0));
System.out.println(Math.floor(-4.0));
	}

}
