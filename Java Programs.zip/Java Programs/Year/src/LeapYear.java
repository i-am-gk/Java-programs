import java.util.Scanner;
public class LeapYear {

	public static void main(String[] args) {
  int year;
  System.out.println("Enter a YEAR:");
  Scanner a= new Scanner(System.in);
  year= a.nextInt();
  if ((year %4 ==0) && (year % 100 !=0))
  System.out.println("Year is a leap year");
  else
	  System.out.print("Year is not  a leap year");
	}
}
