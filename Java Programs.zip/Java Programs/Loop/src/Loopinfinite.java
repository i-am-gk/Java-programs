
public class Loopinfinite {
public void Data() {
	int i=0;
	do {
		System.out.println("Loop Runs "+i+" times");
        i++;	
	}
	while(i<=5);
}
}


