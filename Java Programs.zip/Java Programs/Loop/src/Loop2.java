
public class Loop2 {

	public static void main(String[] args) {
		System.out.println("Calling loop from another class");
		Loopinfinite loop= new Loopinfinite();
		loop.Data();
	}

}
