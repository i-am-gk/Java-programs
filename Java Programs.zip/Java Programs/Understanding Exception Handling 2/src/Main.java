
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=1,b=0,c;

try {
	c=a/b;
	System.out.println(c);
}
catch(Exception e) {
	System.out.println("Arithmetic Error");
	System.out.println(e);
}
	}

}
