
public class Main {
	public static void main(String[] args) {
Employee employee1 = new Employee("Raza", "Khan", 25, 40000.0);
Employee employee2 = new Employee("Shams", "Niaz", 39, 60000.0);
System.out.println("Employee 1 Salary: " + employee1.getSalary());
System.out.println("Employee 2 Salary: " + employee2.getSalary());
employee1.giveRaise(20);
employee2.giveRaise(10);
employee1.compareSalaries(employee2);
//employee2.compareSalaries(employee1);
	    }
}
