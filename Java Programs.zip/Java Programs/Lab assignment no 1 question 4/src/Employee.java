public class Employee {
	// Data Members
    private String FirstName;
    private String LastName;
    private int Age;
    private double Salary;
    // No-parameter constructor
    public Employee() {
        FirstName = "Unknown";
        LastName = "Unknown";
        Age = 0;
        Salary = 0.0;
    }
    // Parameterized constructor
    public Employee(String firstName, String lastName, int age, double salary) {
        FirstName = firstName;
        LastName = lastName;
        Age = age;
        Salary = salary;
    }
    // Copy constructor
    public Employee(Employee otherEmployee) {
        FirstName = otherEmployee.FirstName;
        LastName = otherEmployee.LastName;
        Age = otherEmployee.Age;
        Salary = otherEmployee.Salary;
    }

    // Getter and Setter methods for first name
    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    // Getter and Setter methods for last name
    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    // Getter and Setter methods for age
    public int getAge() {
        return Age;
    }

    public void setAge(int age) {
        Age = age;
    }

    // Getter and Setter methods for salary
    public double getSalary() {
        return Salary;
    }

    public void setSalary(double salary) {
        Salary = salary;
    }

    // Method to give a raise to the employee
    public void giveRaise(double percentage) {
        if (percentage > 0) {
            Salary += (Salary * percentage / 100);
        }
    }

    // Method to compare salaries with another employee
    public void compareSalaries(Employee otherEmployee) {
        double currentSalary = Salary;
        double otherSalary = otherEmployee.Salary;
        if (currentSalary > otherSalary) {
System.out.println("Employee "+FirstName+" "+LastName+" has a higher salary than " + otherEmployee.getFirstName());
        } 
        else if (currentSalary < otherSalary) {
System.out.println("Employee "+FirstName+" "+LastName+" has a higher salary than " + otherEmployee.getFirstName());
        } 
        else {
System.out.println(FirstName + " " + LastName + " has the same salary as " + otherEmployee.getFirstName());
//System.out.println("Employee "+FirstName+" "+LastName+" has a higher salary than" + otherEmployee.getFirstName());       
        }
    }
}
