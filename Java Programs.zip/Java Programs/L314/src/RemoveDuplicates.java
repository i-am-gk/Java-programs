import java.util.*;
public class RemoveDuplicates {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of integers: ");
        int count = scanner.nextInt();
        if (count < 10) {
            System.out.println("Please enter at least ten integers.");
            scanner.close();
            return;
        }

        int[] numbers = new int[count];

        // Read integers into the array
        for (int i = 0; i < count; i++) {
            System.out.print("Enter integer " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        // Invoke the method to remove duplicates
        int[] result = removeDuplicates(numbers);

        // Display the result
        System.out.println("Original Array: " + Arrays.toString(numbers));
        System.out.println("Array with Duplicates Removed: " + Arrays.toString(result));

        scanner.close();
    }

    // Method to remove duplicates from an array
    public static int[] removeDuplicates(int[] arr) {
        Set<Integer> set = new HashSet<>();
        List<Integer> resultList = new ArrayList<>();

        for (int num : arr) {
            if (!set.contains(num)) {
                set.add(num);
                resultList.add(num);
            }
        }

        int[] result = new int[resultList.size()];
        for (int i = 0; i < resultList.size(); i++) {
            result[i] = resultList.get(i);
        }

        return result;
	}

}
