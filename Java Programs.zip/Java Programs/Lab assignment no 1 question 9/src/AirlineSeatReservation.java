import java.util.Scanner;
public class AirlineSeatReservation {
	 private final int TOTAL_SEATS = 10;
	    private boolean[] seats = new boolean[TOTAL_SEATS];
	    public void run() {
	        Scanner scanner = new Scanner(System.in);
	        System.out.println("Welcome to the Airline Seat Reservation System!");
	        while (true) {
System.out.println("Please type 1 for First Class and 2 for Economy (or 0 to quit):");
	            int choice = scanner.nextInt();
	            if (choice == 0) {
	                System.out.println("Thank you for using the Airline Seat Reservation System."
	                		+ " Have a great day!");
	                break;
	            } 
	            else if (choice == 1 || choice == 2) {
	                int seatNumber = assignSeat(choice);
	                if (seatNumber != -1) {
	                    displayBoardingPass(choice, seatNumber);
	                } 
	                else {
System.out.println("The section is full. "
		+ "Would you like to be placed in the other section? (1 for yes, 2 for no)");
	                    int switchChoice = scanner.nextInt();
	                    if (switchChoice == 1) {
	                        int otherChoice;
	                        if (choice == 1) {
	                            otherChoice = 2;
	                        } else {
	                            otherChoice = 1;
	                        }
	                        seatNumber = assignSeat(otherChoice);
	                        if (seatNumber != -1) {
	                            displayBoardingPass(otherChoice, seatNumber);
	                        } else {
	                            System.out.println("I'm sorry, but the other section is also full.");
	                            System.out.println("Next flight leaves in 3 hours.");
	                        }
	                    } else {
	                        System.out.println("Next flight leaves in 3 hours.");
	                    }
	                }
	            } else {
	                System.out.println("Invalid choice. Please type 1 for First Class, 2 for Economy, or 0 to quit.");
	            }
	        }
	    }

	    public int assignSeat(int section) {
	        int startSeat, endSeat;
	        if (section == 1) {
	            startSeat = 0;
	            endSeat = 4;
	        } else {
	            startSeat = 5;
	            endSeat = 9;
	        }

	        for (int i = startSeat; i <= endSeat; i++) {
	            if (!seats[i]) {
	                seats[i] = true;
	                return i + 1; // Seat numbers are 1-based
	            }
	        }

	        return -1; // Section is full
	    }

	    public void displayBoardingPass(int section, int seatNumber) {
	        String sectionName;
	        if (section == 1) {
	            sectionName = "First Class";
	        } else {
	            sectionName = "Economy";
	        }
	        System.out.println("Boarding Pass:");
	        System.out.println("Section: " + sectionName);
	        System.out.println("Seat Number: " + seatNumber);
	        System.out.println("Thank you for choosing our airline!");
	    }

	    
	    }

