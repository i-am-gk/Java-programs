
public class Main {
	public static void main(String[] args) {
        AirlineSeatReservation reservation = new AirlineSeatReservation();
        reservation.run();
}
}
