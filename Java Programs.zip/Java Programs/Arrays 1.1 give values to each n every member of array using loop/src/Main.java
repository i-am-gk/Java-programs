
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=5;
int [] array = new int [a];
for(int i=0;i<array.length;i++)
{
	array[i]=i*2;
}
for(int i=0;i<array.length;i++)
{
	System.out.println(array[i]);
}
	}

}
