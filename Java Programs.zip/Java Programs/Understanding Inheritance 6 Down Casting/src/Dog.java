
public class Dog extends Animal{
	@Override
    void sound() {
        System.out.println("Dog barks");
    }
    void fetch() {
        System.out.println("Dog fetches a ball");
    }
}
