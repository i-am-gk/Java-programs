
public class DowncastingExample {
public static void main(String[] args) {
    // Upcasting: Creating a Dog object and assigning it to an Animal reference
      //Animal animal = new Dog();
       // Downcasting:
      //Casting the reference back to Dog to access specific methods
       /* if (animal instanceof Dog) {
            Dog dog = (Dog) animal;
            dog.fetch(); // Output: Dog fetches a ball
        } else {
            System.out.println("Not a Dog object");
        }*/
	Animal animal = new Dog(); //Obj dog ka reference animal ka
	Dog myDog = (Dog) animal;
	myDog.sound();
    }
}
