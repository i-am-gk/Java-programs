import java.util.ArrayList;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> values = new ArrayList<>();
		System.out.println("Giving values to array list");
		System.out.println("Values are");
	        for (int i = 0; i < 5; i++) {
	            values.add(i*2);
	        }
	        for (int i = 0; i < values.size(); i++) {
	            System.out.println(values.get(i));
	        }
	        }
}
