public class Library {
	private String libraryName;
    private String[] bookNames = new String[3];
    private boolean[] available = new boolean[3];
    public Library(String name) {
        this.libraryName = name;
    }

    public String getLibraryName() {
        return libraryName;
    }
    public void addBook(String book) {
        for (int i = 0; i < 3; i++) {
            if (bookNames[i] == null) {
                bookNames[i] = book;
                available[i] = true;
                System.out.println("Book Added successfully");
                break;
            }
        }
    }

    public void checkout(String bookTitle) {
      for (int i = 0; i < 3; i++) {
      if (bookNames[i] != null && bookNames[i].equals(bookTitle) && available[i]) {
             available[i] = false;
             System.out.println("Book '" + bookTitle + "' checked out successfully.");
              return;
            }
        }
        System.out.println("Book '" + bookTitle + "' not found or already checked out.");
    }

    public void returnBook(String bookTitle) {
        for (int i = 0; i < 3; i++) {
            if (bookNames[i] != null && bookNames[i].equals(bookTitle) && !available[i]) {
                available[i] = true;
                System.out.println("Book '" + bookTitle + "' returned successfully.");
                return;
            }
        }
        System.out.println("Book '" + bookTitle + "' not found or already available.");
    }

    public void compareLibraries(Library otherLibrary) {
        int availableBooksInThisLibrary = 0;
        int availableBooksInOtherLibrary = 0;

        for (int i = 0; i < 3; i++) {
            if (available[i]) {
                availableBooksInThisLibrary++;
            }
            if (otherLibrary.available[i]) {
                availableBooksInOtherLibrary++;
            }
        }

        System.out.println("Comparison of Libraries:");
        System.out.println("Library '" + this.libraryName + "' has " + availableBooksInThisLibrary + " available books.");
        System.out.println("Library '" + otherLibrary.libraryName + "' has " + availableBooksInOtherLibrary + " available books.");
    }

    public void display() {
        System.out.println("Library Name: " + libraryName);
        System.out.println("Library Inventory:");
        for (int i = 0; i < 3; i++) {
            if (bookNames[i] != null) {
                System.out.println("Book Name: " + bookNames[i]);
                System.out.println("Availability: " + (available[i] ? "Available" : "Checked Out"));
            }
        }
    }
}
