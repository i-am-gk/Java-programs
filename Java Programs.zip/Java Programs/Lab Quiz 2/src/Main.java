
public class Main {
	public static void main(String[] args) {
		Library library1 = new Library("Library 1");
        Library library2 = new Library("Library 2");
        library1.addBook("Java");
        library1.addBook("Intro to PF");
        library2.addBook("Education");
        library2.addBook("Aim in Life ");

        library1.display();
        library2.display();

        library1.checkout("Java");
        library2.checkout("Java");

        library1.display();
        library2.display();

        library1.returnBook("Java");
        library2.returnBook("Java");

        library1.display();
        library2.display();

        library1.compareLibraries(library2);
}
}