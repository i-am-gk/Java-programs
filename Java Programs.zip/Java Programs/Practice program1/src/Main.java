import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner (System.in);
int [] array = new int [5];
int sum=0,product=1;
System.out.println("Array program");
for(int i=0;i<5;i++)
{
	System.out.println("Value "+(i+1));
	array[i]=scanner.nextInt();
	sum+=array[i];
	product*=array[i];
}
for(int i=0;i<5;i++)
{
	System.out.println("Value at index "+i+" = "+array[i]);
}
System.out.println("Sum is "+sum);
System.out.println("Product is "+product);


	}

}
