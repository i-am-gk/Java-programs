import java.util.Scanner;
public class Main {
public static void main (String []args) {
	Scanner scanner = new Scanner(System.in);
System.out.println("Enter no");
int no = scanner.nextInt();
System.out.println("Factorial is "+calculatefactorial(no));

}
public static double calculatefactorial(int n) {
if(n<0) {
throw new IllegalArgumentException("Factorial cannot be negative");
}
if(n==0) {
	return 1;
}
else {
	return n*calculatefactorial(n-1);
}
}
}
