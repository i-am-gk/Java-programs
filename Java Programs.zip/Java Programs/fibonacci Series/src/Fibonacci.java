
public class Fibonacci {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int f1=1,f2=1;
System.out.print(f1+ " "+f2+ " ");
int i=3;
while(i<=10)
{
	int f3= f1 + f2;
	System.out.print(f3+ " " );
	f1=f2;
	f2=f3;
	i++;
}
	}

}
