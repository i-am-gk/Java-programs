import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int abt=1,pesh=2,a;
 Bus bus = new Bus(200,20,10);
 Scanner scanner= new Scanner (System.in);
 System.out.println("Amount Available ="+bus.getAmount());
 System.out.println("No of Seats Available ="+bus.getSeat());
 System.out.println("Price per seat ="+bus.getPriceperseat());
 System.out.println ("Bus is going to Abbottabad and Peshwar");
 System.out.println ("1-Abbottabad\n2-Peshawar");
 //for abt price per seat=30 for pesh price per seat=40
 a=scanner.nextInt();
 if (a==1)
	
 {
	 System.out.println("Seat has been Booked - Details now");
     bus.setAmount(bus.getAmount() - bus.getPriceperseat());
     bus.bookSeat();
     System.out.println("Amount remaining is " + bus.getAmount());
     System.out.println("Remaining Seats: " + bus.getSeat());
	 
 }
 else if (a == 2) {
     System.out.println("Seat has been Booked - Details now");
     bus.setAmount(bus.getAmount() - bus.getPriceperseat());
     bus.bookSeat();
     System.out.println("Amount remaining is " + bus.getAmount());
     System.out.println("Remaining Seats: " + bus.getSeat());
 }

 } 
	}

