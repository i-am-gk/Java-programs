
public class Bus {
private int amount=200;// total amount available 200 rs
private int priceperseat=20; // price per seat 20
private int seat=10;// total no of seats available 10
private int bookedSeats = 0; // number of seats booked
public Bus ()
{
	
}
public Bus (int amount,int priceperseat,int seat)
{
	this.amount=amount;
	this.priceperseat=priceperseat;
	this.seat=seat;
}

public int getAmount()
{
	
	return this.amount;
	
}
public void setAmount(int amount)
{
	
	this.amount=amount;
}

public int getPriceperseat()
{
	return this.priceperseat;
}
public void setPriceperseat(int priceperseat )
{
	this.priceperseat=priceperseat;
}
public int getSeat()
{
	return this.seat;
}
public void setSeat(int seat)
{
	this.seat=seat;
}
public int getBookedSeats() {
    return this.bookedSeats;
}
public void bookSeat() {
    if (this.seat > 0) {
        this.seat--;
        this.bookedSeats++;
    }
}

}
