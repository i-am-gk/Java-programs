
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d=new Dog();  
		System.out.println("We will access animal class using dog class object");
		d.eat(); 
		d.bark();  
		
	}

}
