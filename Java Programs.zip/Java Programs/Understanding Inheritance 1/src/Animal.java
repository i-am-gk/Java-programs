
public class Animal {
	void eat(){
		System.out.println("Animal Is Parent Class ");
	}  
	
}
