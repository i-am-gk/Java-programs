
public class Birds {
	public String name="Bird Name";
public void sound() {
	System.out.println("Generic sound of a bird");
}
}
