
public class Eagle extends Birds{
public void sound() {
	System.out.println(super.name);
	System.out.println("Eagle has Different Sound");
}

}
