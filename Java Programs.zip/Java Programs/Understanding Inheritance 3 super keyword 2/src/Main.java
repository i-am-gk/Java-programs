
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Birds birds = new Birds();
Eagle eagle = new Eagle();
birds.sound();
System.out.println("---------------------------");
eagle.sound();

	}

}
