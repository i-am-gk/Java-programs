
public class Die {
	// a field that specifies the number of surfaces on a die.
	private int faces;
	// a non-argument constructor that specifies the default number of surfaces
	public Die () {
	faces = 6;
	}
	// a getter (method) that returns the information of an object
	public int getFaces () {
	return faces;
	}
	// a setter (method) that changes the field's value
	public void setFaces (int numFaces) {
	faces = numFaces;
	} 
	public static void main (String[] args) {
	// create an object of Die class using the non-argument constructor.
	Die d = new Die();
	// test the getFaces method and print out its return value
	System.out.println("value of faces: " + d.getFaces());
	// test the setFaces method
	d.setFaces(4);
	// check if the setFaces method worked
	System.out.println("value of faces after change: " + d.getFaces());
	}

}
