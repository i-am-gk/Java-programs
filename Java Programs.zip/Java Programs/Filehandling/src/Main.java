import java.io.File;
import java.io.IOException;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
File obj = new File("C:\\Users\\vines\\Desktop\\File1.txt");
if(obj.createNewFile()) {
	System.out.println("File Created successfully");
}
else {
	System.out.println("File already exist");
}
		}
catch(IOException e) {
	System.out.println("Error occured while creating"+e.getMessage());
}
	}
		
}