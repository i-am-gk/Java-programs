import java.util.ArrayList;
public class ArrayListExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create an ArrayList to store names (strings)
        ArrayList<String> names = new ArrayList<>();
        // Add elements to the ArrayList
        names.add("Alice");
        names.add("Bob");
        names.add("Charlie");
        names.add("David");
        // Access elements by index
        System.out.println("First name: " + names.get(0));
        System.out.println("Third name: " + names.get(2));
        // Update an element
        names.set(1, "Eve");
        System.out.println("Updated second name: " + names.get(1));
        // Remove an element
        names.remove(3);
        System.out.println("After removing the fourth name: " + names);
        // Check if the ArrayList contains a specific element
        boolean containsCharlie = names.contains("Charlie");
        System.out.println("Contains 'Charlie': " + containsCharlie);
        // Get the size (number of elements) of the ArrayList
        int size = names.size();
        System.out.println("Size of the ArrayList: " + size);
        // Iterate through the ArrayList and print all names
        System.out.println("All names:");
        for (String name : names) {
            System.out.println(name);
        }
	}

}
