import java.util.Scanner;
public class Main {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
InventoryManagementSystem inventorySystem = new InventoryManagementSystem(10);
	        while (true) {
	            System.out.println("\nOptions:");
	            System.out.println("1. Add Product");
	            System.out.println("2. Update Product");
	            System.out.println("3. Delete Product");
	            System.out.println("4. Display Inventory");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();
	            switch (choice) {
	                case 1:
	                    System.out.print("Enter product name: ");
	                    String name = scanner.next();
	                    System.out.print("Enter price: $");
	                    double price = scanner.nextDouble();
	                    System.out.print("Enter quantity: ");
	                    int quantity = scanner.nextInt();
	                    inventorySystem.addProduct(name, price, quantity);
	                    break;
	                case 2:
	                    System.out.print("Enter product name to update: ");
	                    String updateName = scanner.next();
	                    System.out.print("Enter new price: $");
	                    double newPrice = scanner.nextDouble();
	                    System.out.print("Enter new quantity: ");
	                    int newQuantity = scanner.nextInt();
	                    inventorySystem.updateProduct(updateName, newPrice, newQuantity);
	                    break;
	                case 3:
	                    System.out.print("Enter product name to delete: ");
	                    String deleteName = scanner.next();
	                    inventorySystem.deleteProduct(deleteName);
	                    break;
	                case 4:
	                    inventorySystem.displayInventory();
	                    break;
	                case 5:
	                    System.out.println("Exiting the program.");
	                    scanner.close();
	                    System.exit(0);
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }
	    }
}
