public class InventoryManagementSystem {
	private String[] products;
    private double[] prices;
    private int[] quantities;
    private int size;
    public InventoryManagementSystem(int capacity) {
        products = new String[capacity];
        prices = new double[capacity];
        quantities = new int[capacity];
        size = 0;
    }
    public void addProduct(String productName, double price, int quantity) {
        if (size < products.length) {
            products[size] = productName;
            prices[size] = price;
            quantities[size] = quantity;
            size++;
            System.out.println("Product added successfully.");
        } else {
            System.out.println("Inventory is full. Cannot add more products.");
        }
    }

    public void updateProduct(String productName, double newPrice, int newQuantity) {
        for (int i = 0; i < size; i++) {
            if (products[i].equals(productName)) {
                prices[i] = newPrice;
                quantities[i] = newQuantity;
                System.out.println("Product updated successfully.");
                return;
            }
        }
        System.out.println("Product not found in inventory.");
    }

    public void deleteProduct(String productName) {
        for (int i = 0; i < size; i++) {
            if (products[i].equals(productName)) {
                for (int j = i; j < size - 1; j++) {
                    products[j] = products[j + 1];
                    prices[j] = prices[j + 1];
                    quantities[j] = quantities[j + 1];
                }
                size--;
                System.out.println("Product deleted successfully.");
                return;
            }
        }
        System.out.println("Product not found in inventory.");
    }

    public void displayInventory() {
        System.out.println("Inventory:");
        for (int i = 0; i < size; i++) {
 System.out.println(products[i] + " - Price: $" + prices[i] + " - Quantity: " + quantities[i]);
        }
    }
    
}
