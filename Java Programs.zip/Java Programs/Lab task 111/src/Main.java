
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Flight f1= new Flight("ABC "," Abbottabad ", 30 ," Eight O Clock");
Flight f2= new Flight("XYZ "," HARIPUR ", 25 ," THREE O Clock");
int [] flightno= new int [6];
AirlineReservationSystem as = new AirlineReservationSystem();
Passenger p1 = new Passenger ("Ghani ","A905");
Passenger p2 = new Passenger ("James ","X870");
Passenger p = new Passenger();
p1.bookFlight(f1);
p2.bookFlight(f2);
as.displayPassengerReservations(p2);
as.displayPassengerReservations(p1);
System.out.println("----------------------------");
p.displayeven(flightno);

	}

}
