import java.util.ArrayList;
public class Passenger {
private String passengerName;
private String passengerId;
private ArrayList<Flight> reservations = new ArrayList<>();
public Passenger(String passengerName,String passengerId)
{
	this.passengerName=passengerName;
	this.passengerId=passengerId;
}
public Passenger() {
	
}
public String getPassengerName() {
	return passengerName;
}
public String getPassengerId() {
	return passengerId;
}
public void bookFlight(Flight flight) {
	reservations.add(flight);
}
public void cancelFlightReservation(Flight flight) {
	reservations.remove(flight);
}
public void viewReservations() {
	System.out.println("Details ");
	for(Flight flight: reservations) {
		System.out.println(flight);
	}
}
public void displayeven(int [] array) {
	for(int i=0;i<5;i++)
	{
		array[i]= (int)(Math.random()*10);
	if(array[i]%2==0) {
		System.out.println("Even Flights are "+array[i]);
	}
}
	}
public String toString() {
	return "Passenger Name "+passengerName+ " Passenger ID "+passengerId;
}
}