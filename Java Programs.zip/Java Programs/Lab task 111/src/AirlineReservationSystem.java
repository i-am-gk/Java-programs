import java.util.ArrayList;
public class AirlineReservationSystem {
private ArrayList<Flight> flights= new ArrayList<>();
private ArrayList<Passenger> passengers= new ArrayList<>();
public AirlineReservationSystem() {
	this.flights=new ArrayList<>();
    this.passengers=new ArrayList<>();
}
public void addFlight(Flight flight){
	flights.add(flight);
}
public void addPassenger(Passenger passenger){
	passengers.add(passenger);
}
public void makeReservation(Passenger passenger,Flight flight) {
	passenger.bookFlight(flight);
	flight.reserveSeat();
}
public void cancelReservation(Passenger passenger,Flight flight) {
	passenger.cancelFlightReservation(flight);
    flight.cancelReservation();
}
public void displayAvailableFLights() {
	for(Flight flight: flights) {
		System.out.println(flight);
	}
}
public void displayPassengerReservations(Passenger passenger) {
	passenger.viewReservations();
}
}
