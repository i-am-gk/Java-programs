
public class Flight {
private String flightNumber;
private String destination;
private int availableSeats;
private String departureTime;
public Flight(String flightNumber,String destination,int availableSeats,String departureTime) {
	this.flightNumber=flightNumber;
	this.destination=destination;
	this.availableSeats=availableSeats;
	this.departureTime=departureTime;
}
public String getFlightNumber() {
	return flightNumber;
}
public String getDestination() {
	return destination;
}
public int geAvailableSeats() {
	return availableSeats;
}
public void reserveSeat() {
	if(availableSeats>0) {
		availableSeats--;
	}
}
public void cancelReservation() {
	if(availableSeats<0) {
		availableSeats++;
	}
}
	public String toString() {
		return "Flight Number "+flightNumber+ " Destination : "+destination+
				" Available Seats : "+availableSeats+ " Departure Time "+departureTime;
	}
}

