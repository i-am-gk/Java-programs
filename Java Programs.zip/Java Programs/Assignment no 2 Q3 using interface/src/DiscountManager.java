// Implementation of Discountable interface
class DiscountManager implements Discountable {
    // Method to apply a discount to the product's original price
    @Override
    public double applyDiscount(double originalPrice) {
        // Implement discount application logic (sample logic)
        double discountPercentage = 0.2; // 20% discount for simplicity
        return originalPrice - (originalPrice * discountPercentage);
    }
}