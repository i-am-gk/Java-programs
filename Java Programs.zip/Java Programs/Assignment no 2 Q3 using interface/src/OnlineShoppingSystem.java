import java.util.ArrayList;
public class OnlineShoppingSystem {
public static void main(String[] args) {
// Create instances of ElectronicProduct and ClothingProduct
ElectronicProduct electronicProduct = new ElectronicProduct("Smart TV",
40000.0, 3);
ClothingProduct clothingProduct = new ClothingProduct("Jeans", 2500.5, "Large");
// Create a list of products
 ArrayList<Product> products = new ArrayList<>();
products.add(electronicProduct);
products.add(clothingProduct);
  // Calculate and display total price for each product
   for (Product product : products) {
   double totalPrice = product.calculateTotalPrice();
   System.out.println("Product: " + product.productName + ""
   + ", Total Price: $" + totalPrice);
// Apply discount for products that implement the Discountable
//interface
 if (product instanceof Discountable) {
 Discountable discountableProduct = (Discountable) product;
 double discountedPrice =
 discountableProduct.applyDiscount(totalPrice);
 System.out.println("Discounted Price: $" + discountedPrice);
            }
System.out.println(); // Add a line break for better readability
        }
    }
}