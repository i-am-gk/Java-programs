// Subclass 1 - ElectronicProduct
class ElectronicProduct extends Product {
    int warrantyPeriod;
    // Constructor
    ElectronicProduct(String productName, double price, int warrantyPeriod) {
        super(productName, price);
        this.warrantyPeriod = warrantyPeriod;
    }
    public int getWarrantyPeriod() {
    	return warrantyPeriod;
    }
    public void setWarrantyPeriod(int warrantyPeriod) {
    	this.warrantyPeriod=warrantyPeriod;
    }
    // Override calculateTotalPrice method
    @Override
    double calculateTotalPrice() {
        return price + 0.4 * price; // Assuming a 10% tax for simplicity
    }
}
