// Subclass 2 - ClothingProduct
class ClothingProduct extends Product {
    String size;
    ClothingProduct(String productName, double price, String size) {
        super(productName, price);
        this.size = size;
    }
    public String getsize() {
    	return size;
    }
    public void setSize(String size) {
    	this.size=size;
    }
    // Override calculateTotalPrice method
    @Override
    double calculateTotalPrice() {
        return price;
    }
}
// Interface - Discountable
interface Discountable {
    double applyDiscount(double originalPrice);
}
