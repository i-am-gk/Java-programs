// Abstract Base Class - Product
abstract class Product {
    String productName;
    double price;
    // Constructor
    Product(String productName, double price) {
        this.productName = productName;
        this.price = price;
    }
    public String getProductName() {
    	return productName;
    }
    public void setProductName(String productName) {
    	this.productName=productName;
    }
    public double getPrice() {
    	return price;
    }
    public void setPrice(double price) {
    	this.price=price;
    }
    // Abstract method to calculate total price
    abstract double calculateTotalPrice();
}
