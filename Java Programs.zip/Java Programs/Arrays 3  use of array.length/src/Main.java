import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] arr=new int [5];
Scanner scanner=new Scanner(System.in);
System.out.println("Enter Values for array ");
for(int i=0;i<5;i++)
{
arr[i]=scanner.nextInt();
}
for(int i=0;i<arr.length;i++)
{
	System.out.println("value "+i+ " index "+arr[i]);
}
	}

}
