public class StudentManagement {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create an array to store student objects
        Student[] studentArray = new Student[3];
        // Initialize student objects and store them in the array
        studentArray[0] = new Student("Ghani", 20);
        studentArray[1] = new Student("Ali", 20);
        studentArray[2] = new Student("GKD", 22);
        // Access and display information of each student in the array
        for (int i = 0; i < 3; i++) {
            Student gk = studentArray[i];
            System.out.println("Student " + (i + 1) + ":");
            System.out.println("Name: " + gk.getName());
            System.out.println("Age: " + gk.getAge());
            System.out.println();
	}

}
}
;