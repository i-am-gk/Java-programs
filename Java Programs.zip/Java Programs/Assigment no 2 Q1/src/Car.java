// Subclass 1 - Car
class Car extends Vehicle {
    int numPassengers;

    // Constructor
    Car(String licensePlate, int numPassengers) {
        this.licensePlate = licensePlate;
        this.type = "Car";
        this.numPassengers = numPassengers;
    }

    // Override calculateToll method
    @Override
    double calculateToll() {
        // Implement toll calculation for cars (sample logic)
        return 5.0 * numPassengers;
    }
}