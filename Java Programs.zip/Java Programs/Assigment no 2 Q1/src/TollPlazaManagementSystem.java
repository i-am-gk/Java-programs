import java.util.ArrayList;
import java.util.Random;
public class TollPlazaManagementSystem {
    public static void main(String[] args) {
        // Create instances of Car and Truck
        Car car = new Car("ABC123", 3);
        Truck truck = new Truck("XYZ789", 5000.0);

        // Create a TollBooth
        TollBooth tollBooth = new TollBooth();

        // Add vehicles to the toll booth
        tollBooth.addVehicle(car);
        tollBooth.addVehicle(truck);

        // Generate a random number between 1 and 3
        Random random = new Random();
        int randomNum = random.nextInt(3) + 1;

        // If the random number is 1, place the first object at the first index
        if (randomNum == 1) {
            System.out.println("The first vehicle is placed at the first index.");
            tollBooth.collectTollForAll();
        }
    }
}