// Abstract Base Class - Vehicle
abstract class Vehicle {
    String licensePlate;
    String type;

    // Abstract method to calculate toll
    abstract double calculateToll();
}