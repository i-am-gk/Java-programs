// TollBooth class
import java.util.ArrayList;
import java.util.Random;
class TollBooth {
    private ArrayList<Vehicle> vehicles;

    // Constructor
    TollBooth() {
        vehicles = new ArrayList<>();
    }

    // Method to collect toll for a given vehicle
    void collectToll(Vehicle vehicle) {
        double tollAmount = vehicle.calculateToll();
        System.out.println("Collecting toll for " + vehicle.type + " with license plate " + vehicle.licensePlate +
                ": $" + tollAmount);
    }

    // Method to add a vehicle to the toll booth
    void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }

    // Method to simulate toll collection for all vehicles in the toll booth
    void collectTollForAll() {
        for (Vehicle vehicle : vehicles) {
            collectToll(vehicle);
        }
    }
}