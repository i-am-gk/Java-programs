// Subclass 2 - Truck
class Truck extends Vehicle {
    double cargoWeight;

    // Constructor
    Truck(String licensePlate, double cargoWeight) {
        this.licensePlate = licensePlate;
        this.type = "Truck";
        this.cargoWeight = cargoWeight;
    }

    // Override calculateToll method
    @Override
    double calculateToll() {
        // Implement toll calculation for trucks (sample logic)
        return 10.0 * cargoWeight;
    }
}
