import java.util.Scanner;
public class Numbercheck {
public static void main (String []args) {
	int num;
	System.out.print("Enter an integer");
    Scanner abc = new Scanner(System.in);
    num = abc.nextInt();
    abc.close();
    if(num%2==0)
    System.out.print("You entered an even number");
    else
    	System.out.print("You entered odd number");
}
}
