
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // Create an instance of the Animal class
        Animal genericAnimal = new Animal();
        // Accessing and printing the sound field from the Animal class
        System.out.println("Animal Sound: " + genericAnimal.sound);
        // Call the makeSound method of the Animal class
        genericAnimal.makeSound();  // Output: Generic animal sound
        // Create an instance of the Cat class
        Cat myCat = new Cat();
        // Accessing and printing the sound field from the Animal class using super
        System.out.println("Cat Sound: " + myCat.sound);
        // Call the makeSound method of the Cat class, which invokes the superclass's makeSound using super
        myCat.makeSound();
        // Output:
        // Generic animal sound
        // Meow, meow!
	}

}
