
public class Cat extends Animal {
	 @Override
	    void makeSound() {
	        super.makeSound(); // Invoking the overridden method from the superclass
	        System.out.println("Meow, meow!");
	    }	
}
