public class Animal {
	String sound = "Animal Sound";
    void makeSound() {
        System.out.println("Generic animal sound");
    }
}
