
class Animal {
	public void Introduction() {
   System.out.println("Generic Animal");
}
}
class Dog extends Animal {
	public void Introduction() {
	 System.out.println("Dog is a specific type of Animal");
}}

class Cat extends Animal {
	public void Introduction() {
	System.out.println("Cat is a specific type of Animal");
}
}
public class Main {
    public static void main(String[] args) {
        Animal myPet = new Dog();
        if (myPet instanceof Dog) {
            System.out.println("My pet is a Dog!");
        }
        else if (myPet instanceof Cat) {
            System.out.println("My pet is a Cat!");
        } 
        else {
            System.out.println("My pet is some other kind of Animal.");
        }
    }
}
