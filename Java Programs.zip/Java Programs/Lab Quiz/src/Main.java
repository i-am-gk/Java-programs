
public class Main {
	public static void main(String[] args) {
        Library library1 = new Library("Library 1");
        library1.addBook("Book 1");
        library1.addBook("Book 2");
        library1.addBook("Book 3");

        Library library2 = new Library("Library 2");
        library2.addBook("Book 1");
        library2.addBook("Book 4");

        library1.displayInventory();
        library2.displayInventory();

        library1.compareLibraries(library2);

        library1.checkOutBook("Book 1");
        library1.displayInventory();
        library2.displayInventory();
    }
}
