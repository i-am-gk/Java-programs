import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 double distance;
		Scanner inp = new Scanner(System.in);
		double efficiency = 5.0; // Fuel efficiency in km per liter
        double fuelAmount = 5.0; // Fuel amount in liters
        System.out.println("Enter distance ");
        distance=inp.nextDouble();
  Car myCar = new Car(efficiency);
     distance = myCar.calculateDistance(fuelAmount);
System.out.println("The car can travel " + distance + " kilometers with " + fuelAmount + 
		" liters of fuel.");
	}

}
