
public class Car {
	private double fuelEfficiency; // km per liter

    public Car(double efficiency) {
        this.fuelEfficiency = efficiency;
    }

    public double calculateDistance(double fuelAmount) {
        return fuelAmount * fuelEfficiency;
    }
}
