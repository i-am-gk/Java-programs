import java.util.Arrays;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] array = {9,8,7,6,5,4,3,2,1};
System.out.println("Before Sorting array is");
for(int i=0;i<array.length;i++)
{
	System.out.print(" "+array[i]);
}
System.out.println();
System.out.println("After Sorting array is");
Arrays.sort(array);
for(int i=0;i<array.length;i++)
{
	System.out.print(""+array[i]);
	
}
	}

}
