
public class factorialofnumber {
public double calculateFactorial(int n) {
	if (n < 0) {
throw new IllegalArgumentException("Factorial is not "
		+ "defined for negative numbers.");
    }
    /* int result = 1;
    // Calculate factorial using a loop
    for (int i = 1; i <= n; i++) {
        result *= i;
    }

    //return result;
}*/
	// logic 2
	int k=1;
	for(int i=n; i>=1;i--) {
		k=k*i;
	}
	return k;
}
}
