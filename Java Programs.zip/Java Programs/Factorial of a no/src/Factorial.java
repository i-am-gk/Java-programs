import java.util.Scanner;
public class Factorial {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		factorialofnumber f = new factorialofnumber ();
        // Input: Get the number for which factorial needs to be calculated
        System.out.print("Enter a non-negative integer: ");
        int number = scanner.nextInt();
        // Calculate and display the factorial
 System.out.println("Factorial is "+f.calculateFactorial(number));
        scanner.close();
	}

}
