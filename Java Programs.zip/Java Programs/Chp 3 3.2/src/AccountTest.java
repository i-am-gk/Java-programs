
public class AccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// create two Account objects 
		Account account1 = new Account("Jane Green");
		Account account2 = new Account("John Blue");
		Account account3 = new Account ("Ghani Khan");
		// display initial value of name for each Account
		System.out.printf("account1 name is: %s%n", account1.getName());
	System.out.printf("account2 name is: %s%n", account2.getName());
	System.out.printf("account2 name is: %s%n", account3.getName());
	}

}
