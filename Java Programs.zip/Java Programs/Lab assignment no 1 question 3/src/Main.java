
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // Create a rectangle using the no-parameter constructor
Rectangle rectangle1 = new Rectangle(2.0, 4.0);
        // Create a rectangle using the parameterized constructor
Rectangle rectangle2 = new Rectangle();
        // Create a copy of rectangle2 using the copy constructor
Rectangle rectangle3 = new Rectangle(rectangle1);
        // Print area and perimeter of rectangle1
System.out.println("Rectangle 1 - Area: " + rectangle1.calculateArea() + ", Perimeter: " + rectangle1.calculatePerimeter());
        // Print area and perimeter of rectangle2
System.out.println("Rectangle 2 - Area: " + rectangle2.calculateArea() + ", Perimeter: " + rectangle2.calculatePerimeter());
        // Compare areas of rectangle2 and rectangle1
rectangle2.compareAreas(rectangle1);
	}

}
