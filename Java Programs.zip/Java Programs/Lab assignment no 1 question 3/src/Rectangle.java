public class Rectangle {
	private double width;
    private double height;
    // No-parameter constructor
    public Rectangle() {
        this.width = 1.0;
        this.height = 1.0;
    }
    // Parameterized constructor
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }
    // Copy constructor
    public Rectangle(Rectangle otherRectangle) {
        this.width = otherRectangle.width;
        this.height = otherRectangle.height;
    }
    // Getter and Setter methods for width
    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    // Getter and Setter methods for height
    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    // Method to calculate the area of the rectangle
    public double calculateArea() {
        return width * height;
    }

    // Method to calculate the perimeter of the rectangle
    public double calculatePerimeter() {
        return 2 * (width + height);
    }
    // Method to compare areas with another rectangle
    public void compareAreas(Rectangle otherRectangle) {
  double area1 = calculateArea();
  double area2 = otherRectangle.calculateArea();
  if (area1 > area2) {
  System.out.println("The area of the current rectangle is greater.");
      } 
  else if (area2 > area1) {
    	  System.out.println("The area of the other rectangle is greater.");
        } 
  else {
           System.out.println("The areas of both rectangles are equal.");
        }
    }
    
}
