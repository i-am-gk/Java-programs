public class BankAccount {
    // Data Members
    private String AccountNo;
    private String AccountTitle;
    private double AccountBalance;
    private boolean AccountStatus;
    // No-parameter constructor
    public BankAccount() {
        AccountTitle = "Unknown";
        AccountNo = "N/A";
        AccountBalance = 0.0;
        AccountStatus = true;
    }

    // Parameterized constructor
    public BankAccount(double initialBalance,String title,String accountNo ) {
      this.AccountTitle = title;
      this.AccountNo = accountNo;
        this.AccountBalance = initialBalance;
        this.AccountStatus = true;
    }

    // Copy constructor
    public BankAccount(BankAccount otherAccount) {
       this.AccountTitle = otherAccount.AccountTitle;
       this. AccountNo = otherAccount.AccountNo;
       this.  AccountBalance = otherAccount.AccountBalance;
       this. AccountStatus = otherAccount.AccountStatus;
    }

    // Getter and Setter methods for account holder's name
    public String getAccountTitle() {
        return AccountTitle;
    }

    public void setAccountTitle(String title) {
        AccountTitle = title;
    }

    // Getter and Setter methods for account number
    public String getAccountNo() {
        return AccountNo;
    }

    public void setAccountNo(String accountNo) {
        this.AccountNo = accountNo;
    }

    // Getter method for account balance
    public double getAccountBalance() {
        return AccountBalance;
    }

    // Method to deposit funds
    public void deposit(double amount) {
        if (amount > 0) {
            AccountBalance += amount;
        }
    }

    // Method to withdraw funds
    public void withdraw(double amount) {
        if (AccountStatus && amount > 0 && AccountBalance >= amount) {
            AccountBalance -= amount;
        }
    }

    // Method to transfer funds to another account
    public void transfer(BankAccount recipient, double amount) {
if (AccountStatus && recipient.AccountStatus && amount > 0 && AccountBalance >= amount) {
            withdraw(amount);
            recipient.deposit(amount);
        }
    }

    // Method to deactivate the account
    public void deactivateAccount() {
        AccountStatus = false;
    }

    // Method to activate the account
    public void activateAccount() {
        AccountStatus = true;
    }

    // Method to check if the account is active
    public boolean isAccountActive() {
        return AccountStatus;
    }
}
