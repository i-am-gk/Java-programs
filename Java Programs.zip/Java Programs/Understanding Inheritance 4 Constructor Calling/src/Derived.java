
public class Derived extends Base {
Derived(){
	System.out.println("Derived class constructor");
}
}
