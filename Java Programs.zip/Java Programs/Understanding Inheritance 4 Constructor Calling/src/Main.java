
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=3;
Derived d = new Derived();
Derived d = new Derived(b);
	}

}
