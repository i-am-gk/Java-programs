
public class Base {
	int a=5;
Base(){
	System.out.println("Base class constructor");
}
Base (int a){
	System.out.println(a);
}
}
