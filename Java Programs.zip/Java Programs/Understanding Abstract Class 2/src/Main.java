public class Main {
    public static void main(String[] args) {
        // You cannot create an instance of an abstract class
        // ElectronicDevice device = new ElectronicDevice(); // This line will result in an error

        // But you can create instances of its subclasses
        Laptop laptop = new Laptop("Dell");
        laptop.displayBrand();
        laptop.turnOn();
        laptop.openLid();
        laptop.turnOff();

        Smartphone smartphone = new Smartphone("Samsung");
        smartphone.displayBrand();
        smartphone.turnOn();
        smartphone.makeCall("123-456-7890");
        smartphone.turnOff();
    }
}