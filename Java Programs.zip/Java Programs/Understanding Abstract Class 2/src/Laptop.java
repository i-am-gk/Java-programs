// Concrete subclass 1
class Laptop extends ElectronicDevice {
    // Constructor
    Laptop(String brand) {
        super(brand);
    }/*The super(brand) in the Laptop constructor is calling the constructor
     of the immediate parent class (ElectronicDevice) and passing the
      brand parameter to it.   */
    // Implementation of abstract method
    void turnOn() {
        System.out.println("Laptop is turning on...");
    }
    // Implementation of abstract method
    void turnOff() {
        System.out.println("Laptop is turning off...");
    }
    // Additional method specific to Laptop
    void openLid() {
        System.out.println("Laptop lid is open.");
    }
}
