// Abstract class
abstract class ElectronicDevice {
    private String brand;
    // Constructor
    ElectronicDevice(String brand) {
        this.brand = brand;
    }
    // Abstract method
    abstract void turnOn();
    // Abstract method
    abstract void turnOff();
    // Concrete method
    void displayBrand() {
        System.out.println("Brand: " + brand);
    }
}