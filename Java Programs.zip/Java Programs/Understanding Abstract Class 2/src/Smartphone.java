// Concrete subclass 2
class Smartphone extends ElectronicDevice {
    // Constructor
    Smartphone(String brand) {
        super(brand);
    }

    // Implementation of abstract method
    void turnOn() {
        System.out.println("Smartphone is turning on...");
    }

    // Implementation of abstract method
    void turnOff() {
        System.out.println("Smartphone is turning off...");
    }

    // Additional method specific to Smartphone
    void makeCall(String number) {
        System.out.println("Calling " + number);
    }
}