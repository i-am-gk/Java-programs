import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
int [] array = new int [5];
System.out.println("Sum of elements using enhanced for loop");
for(int i=0;i<array.length;i++) {
	System.out.println("Value "+(i+1));
	array[i]=scanner.nextInt();
}
for(int i=0;i<array.length;i++) {
	System.out.println("Value "+array[i]+ " Index "+i);
}
int sum=0;
for(int number:array)
{
	sum+=number;
}
System.out.println("Sum of array is "+sum);
	}

}
