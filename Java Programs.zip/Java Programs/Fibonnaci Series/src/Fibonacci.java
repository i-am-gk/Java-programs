
public class Fibonacci {
public int generateFibonacci(int a)
{
	int first = 1;
    int second = 1;
    System.out.print(first + " " + second + " ");
    int result=0;
    for (int i = 3; i <= a; i++) {
        int next = first + second;
        System.out.print(next + " ");
        first = second;
        second = next;
        next=result;
    }
    return result;
}
	
}

