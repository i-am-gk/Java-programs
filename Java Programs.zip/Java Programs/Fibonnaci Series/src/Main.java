
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10; // Change this to the number of Fibonacci
		//numbers you want to generate
        Fibonacci f = new Fibonacci();
        int k = f.generateFibonacci(n);
        System.out.println(k);
	}

}
