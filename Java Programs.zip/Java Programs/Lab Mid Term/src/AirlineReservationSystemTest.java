
public class AirlineReservationSystemTest {
    public static void main(String[] args) {
        // Create flights
        Flight f1 = new Flight("Abbottabad", "FA607", "8am", 5);
        Flight f2 = new Flight("Lahore", "B9990", "11pm", 10);
        // Create passengers
        Passenger p1 = new Passenger("ABC", "101");
        Passenger p2 = new Passenger("XYZ", "009");
        // Create AirlineReservationSystem
        AirlineReservationSystem ar = new AirlineReservationSystem();
        // Reserve seats for flight f1
        f1.reserveSeats();
        // Book flight f1 for passenger p1
        p1.bookFlight(f1);
        // Display reservations for passenger p1
        System.out.println("\nReservations for Passenger " + p1.getPassengerName() + ":");
        p1.viewReservations();
        // Cancel reservation for flight f1 for passenger p1
        f1.cancelReservation();
        // Book flight f2 for passenger p1
        p1.bookFlight(f2);
        // Add flight f2 to the AirlineReservationSystem
        ar.addFlight(f2);
        // Display available flights in the AirlineReservationSystem
        System.out.println("\nAvailable Flights in the AirlineReservationSystem:");
        ar.displayAvailableFlights();
        // Display reservations for all passengers
        System.out.println("\nReservations for all Passengers:");
        ar.displayPassengerReservations();
    }
}
