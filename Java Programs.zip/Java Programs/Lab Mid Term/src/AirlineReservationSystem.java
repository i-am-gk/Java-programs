import java.util.ArrayList;
public class AirlineReservationSystem {
private ArrayList<Flight>flights = new ArrayList<>();
private ArrayList<Passenger>passengers = new ArrayList<>();
AirlineReservationSystem (){
	this.flights=flights;
	this.passengers=passengers;
}
public void addFlight(Flight flight) {
	flights.add(flight);
}
public void addPassenger(Passenger passenger) {
	passengers.add(passenger);
}
public void makeReservation(Passenger passenger, Flight flight) {
	passenger.bookFlight(flight);
}
public void cancelReservation(Passenger passenger, Flight flight) {
	passenger.cancelFlightReservation(flight);
}
public void displayAvailableFlights() {
    for (Flight flight : flights) {
        System.out.println(flight);
    }
}
    public void displayPassengerReservations() {
        for (Passenger passenger : passengers) {
            System.out.println(passenger);
        }

}
}
