import java.util.ArrayList;
public class Passenger {
private String name;
private String id;
private ArrayList<Flight> reservations = new ArrayList<>();
Passenger(String name, String id) {
    this.name = name;
    this.id = id;
    this.reservations = new ArrayList<>();
}
public String getPassengerName() {
	return name;
}
public String getPassengerID() {
	return id;
}
public void bookFlight(Flight flight) {
	reservations.add(flight);
}
public void cancelFlightReservation(Flight flight) {
    reservations.remove(flight);
}
public void viewReservations() {
    for (Flight flight : reservations) {
        System.out.println(flight);
    }
}
public String toString() {
	return "Passenger Name: "+name+ "Passenger ID: "+id;
}
}
