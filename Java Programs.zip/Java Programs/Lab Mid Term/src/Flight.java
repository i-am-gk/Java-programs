
public class Flight {
private String destination;
private String flightNumber;
private String departureTime;
private int availableSeats;
public Flight(String destination, String flightNumber, String departureTime, int availableSeats) {
    this.destination = destination;
    this.flightNumber = flightNumber;
    this.departureTime = departureTime;
    this.availableSeats = availableSeats;
}

public String getFlightNumber() {
	return flightNumber;
}
public String getDesitination() {
	return destination;
}
public int getAvailableSeats() {
	return availableSeats;
}
public void reserveSeats() {
	if(availableSeats>0) {
		availableSeats--;
	}
}
public void cancelReservation() {
    if (availableSeats > 0) {
        availableSeats++;
    }
}
public String toString() {
	return "Flight Details\n"+
"Destination: "+destination+ "\nFlight no: "+flightNumber+
"\nAvailable Seats: "+availableSeats+ "\nDeparture Time :" +departureTime;
}
}
