
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Animal a = new Animal();// Animal reference and object
Animal b = new Dog();// Animal Reference but dog object
a.move();
b.move();
	}
}
