import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array = new int [10];
		int a,value=0;
Scanner scanner = new Scanner(System.in);
System.out.println("Enter the value you want to check");
 a=scanner.nextInt();
System.out.println("Enter 10 values of your choice but from 1-10");
for(int i=0;i<array.length;i++)
{
	array[i]=scanner.nextInt();
	if(a==array[i])
	{
		value++;
	}
}
System.out.println("Value " +a+ " occurs "+value+" times");

	}

}
