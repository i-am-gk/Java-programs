import java.util.ArrayList;
public class SimpleArrayListExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create an ArrayList of integers
        ArrayList<Integer> numbers = new ArrayList<>();
        // Add numbers to the ArrayList
        numbers.add(5);
        numbers.add(10);
        numbers.add(15);
        // Access and print elements from the ArrayList
        System.out.println("Elements in the ArrayList:");
        for (int i = 0; i < numbers.size(); i++) {
            System.out.println(numbers.get(i));
        }
        // Add another number
        numbers.add(20);
        // Remove the second number (index 1)
        numbers.remove(1);
        // Print the updated ArrayList
        System.out.println("\nUpdated elements in the ArrayList:");
        for (int number : numbers) {
            System.out.println(number);
        }
	}

}
