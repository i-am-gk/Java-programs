import java.util.ArrayList;
public class ArrayListExample {
    public static void main(String[] args) {
        // Create an ArrayList of strings
        ArrayList<String> fruits = new ArrayList<>(); 
        // Add elements
        fruits.add("Apple");//index 0
        fruits.add("Banana");//index 1
        fruits.add("Cherry");//index 2
        // Access elements
        String firstFruit = fruits.get(0);
        System.out.println("Way 1");
        System.out.println("First fruit: " + firstFruit);
        System.out.println("Way 2");
        System.out.println("First fruit: " +fruits.get(0));
        // Remove an element
        fruits.remove(1);
        System.out.println("Updated list: " + fruits);
    }
}