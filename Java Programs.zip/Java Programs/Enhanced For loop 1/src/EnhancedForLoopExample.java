import java.util.ArrayList;
public class EnhancedForLoopExample {
public static void main(String[] args) {
// TODO Auto-generated method stub
	// Example with an array
    int[] numbers = {1, 2, 3, 4, 5};
    // Traditional for loop
    System.out.println("Using traditional for loop:");
    for (int i = 0; i < numbers.length; i++) {
        System.out.println(numbers[i]);
    }
    // Enhanced for loop (for-each loop)
    System.out.println("\nUsing enhanced for loop:");
    for (int number : numbers) {
        System.out.println(number);
    }
    // Example with a collection (ArrayList)
    System.out.println("\nExample with ArrayList:");
    // Creating an ArrayList of strings
    ArrayList<String> fruits = new ArrayList<>();
    fruits.add("Apple");
    fruits.add("Banana");
    fruits.add("Orange");

    // Enhanced for loop for iterating over ArrayList
    for (String fruit : fruits) {
        System.out.println(fruit);
    }
	
	}

}
