
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating objects using constructors
        Person person1 = new Person("Alice", 25);
        Person person2 = new Person();

        // Displaying information
        System.out.println("Person 1:");
        person1.displayInfo();

        System.out.println("\nPerson 2:");
        person2.displayInfo();
	}

}
