
public class Working {
public static String name="GK";
public static void main (String []args) {
	System.out.println("Name :"+Working.name);
}

}
/* jab b variable class kay andar magar method say bahar ho wo global ya instance variable hota
 * aur jab variable mehtod kay andar ho wo local hota
 * and  agar static keyword use krtay variable static hai to object bnanay ki zarorat nai
 * jaisay static method mein hota hai
 *  */
 