
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
int i=1,j=5;
System.out.println("Before process Value of i="+i+"Value of j="+j);
j=++i;
System.out.println("After process Value of i="+i+"Value of j="+j);
System.out.println("............................................");
int a=10,b=50;
System.out.println("Before process Value of a="+a+"Value of b="+b);
b=a--;
System.out.println("After process Value of a="+a+"Value of b="+b);
System.out.println("............................................");
int c=5,d=10;
System.out.println("Before process Value of c="+c+"Value of d="+d);
c++;
++d;
System.out.println("After process Value of c="+c+"Value of d="+d);
	}

}
