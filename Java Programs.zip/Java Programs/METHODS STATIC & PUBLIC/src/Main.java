
public class Main {
public static void main (String [] args)
{
String first="GK";	
String second="AUST";
System.out.println("" +first);
System.out.println(second);


	}
}