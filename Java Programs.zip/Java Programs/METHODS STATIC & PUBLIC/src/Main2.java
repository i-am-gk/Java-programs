
public class Main2 {

	public static void main(String[] args) {
	Main obj=new Main();
	obj.setName("GK");
	System.out.println(obj.getName());

}
}