import java.util.Scanner;
public class Result {
	private int rollNo;
    private String name;
    private int[] marks = new int[3];
    // Member function to input values
    public void input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Roll No: ");
        rollNo = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        System.out.print("Enter Name: ");
        name = scanner.nextLine();
        
        System.out.println("Enter Marks for 3 Subjects:");
        for (int i = 0; i < 3; i++) {
            System.out.print("Subject " + (i + 1) + ": ");
            marks[i] = scanner.nextInt();
        }
    }

    // Member function to display values
    public void show() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Marks:");
        for (int i = 0; i < 3; i++) {
            System.out.println("Subject " + (i + 1) + ": " + marks[i]);
        }
    }

    // Member function to calculate and return total marks
    public int total() {
        int totalMarks = 0;
        for (int mark : marks) {
            totalMarks += mark;
        }
        return totalMarks;
    }

    // Member function to calculate and return average marks
    public double avg() {
        int totalMarks = total();
        return (double) totalMarks / marks.length;
    }
}

