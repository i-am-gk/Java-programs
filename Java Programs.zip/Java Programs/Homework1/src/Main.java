
public class Main {
	public static void main(String[] args) {
        Result student = new Result();
        
        // Input values using the input() method
        student.input();
        
        // Display values using the show() method
        System.out.println("Student Information:");
        student.show();
        
        // Calculate and display total marks
        int totalMarks = student.total();
        System.out.println("Total Marks: " + totalMarks);
        
        // Calculate and display average marks
        double averageMarks = student.avg();
        System.out.println("Average Marks: " + averageMarks);
    }
}
