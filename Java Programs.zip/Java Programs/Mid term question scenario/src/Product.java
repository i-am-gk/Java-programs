public class Product {
	 private int productID;
	    private String productName;
	    private double price;
	    private int quantity;
	    Product (){
	    	
	    }
	    public Product(int productID, String productName, double price, int quantity) {
	        this.productID = productID;
	        this.productName = productName;
	        this.price = price;
	        this.quantity = quantity;
	    }
	    // Getters and setters for Product class
	    public int getProductID() {
	        return productID;
	    }
	    public String getProductName() {
	        return productName;
	    }
	    public double getPrice() {
	        return price;
	    }
	    public int getQuantity() {
	        return quantity;
	    }
	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }
	    @Override
	    public String toString() {
	        return "Product ID: " + productID +
	                ", Product Name: " + productName +
	                ", Price: $" + price +
	                ", Quantity: " + quantity;
	    }
}