import java.util.ArrayList;
public class ShoppingCart {
	  private String customerName;
	    private ArrayList<Product> cartItems= new ArrayList<>();
	    Product product = new Product();
	    public ShoppingCart(String customerName) {
	        this.customerName = customerName;
	    }
	    // Add product to the shopping cart
	    public void addProductToCart(Product product) {
	        cartItems.add(product);
	    }
	    // Remove product from the shopping cart
	    public void removeProductFromCart(Product product) {
	        cartItems.remove(product);
	    }
	    // Calculate the total cost of items in the cart
	    public double calculateTotal() {
	        double total = 0;
	        for (Product product : cartItems) {
	            total += product.getPrice() * product.getQuantity();
	        }
	        return total;
	    }
	    // Display the contents of the cart
	    public void printCart() {
	        System.out.println("Customer: " + customerName);
	        System.out.println("Cart Contents:");
	        for (Product product : cartItems) {
	            System.out.println(product);
	        }
	        System.out.println("Total: $" + calculateTotal());
	    }
	    // Compare two shopping carts
	    public void compareCart(ShoppingCart otherCart) {
	        int size1 = this.cartItems.size();
	        int size2 = otherCart.cartItems.size();
	        if (size1 > size2) {
	            System.out.println("Cart1 contains more products than Cart2.");
	        } else if (size1 < size2) {
	            System.out.println("Cart1 contains fewer products than Cart2.");
	        } else {
	            System.out.println("Cart1 contains an equal number of products as Cart2.");
	        }
	    }
}
