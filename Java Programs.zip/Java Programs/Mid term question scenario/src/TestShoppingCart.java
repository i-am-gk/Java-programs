public class TestShoppingCart {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // Creating products
        Product product1 = new Product(1, "Laptop", 1200.00, 2);
        Product product2 = new Product(2, "Mouse", 20.00, 5);
        Product product3 = new Product(3, "Headphones", 50.00, 1);
        // Creating a shopping cart
        ShoppingCart cart1 = new ShoppingCart("ABC");
        // Adding products to the cart
        cart1.addProductToCart(product1);
        cart1.addProductToCart(product2);
        cart1.addProductToCart(product3);
        // Creating another shopping cart
        ShoppingCart cart2 = new ShoppingCart("XYZ");
        // Adding products to the second cart
        cart2.addProductToCart(product1);
        cart2.addProductToCart(product2);
        // Displaying the contents of the carts
        System.out.println("Cart1:");
        cart1.printCart();
        System.out.println("\nCart2:");
        cart2.printCart();
        // Comparing the two carts
        System.out.println("\nComparing Carts:");
        cart1.compareCart(cart2);
	}

}
