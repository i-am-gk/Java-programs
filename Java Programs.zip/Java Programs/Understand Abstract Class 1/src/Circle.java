// Concrete subclass 1
class Circle extends Shape {
    double radius;
    Circle(double radius) {
        this.radius = radius;
    }
    // Implementation of the abstract method
    void draw() {
        System.out.println("Drawing a circle");
    }
    // Additional method specific to Circle
    double calculateArea() {
        return Math.PI * radius * radius;
    }
}
