public class Main {
    public static void main(String[] args) {
        // You cannot create an instance of an abstract class
        // Shape shape = new Shape(); // This line will result in an error
        // But you can create instances of its subclasses
        Circle circle = new Circle(5);
        circle.draw();
        circle.displayArea();
        System.out.println("Area of Circle: " + circle.calculateArea());

        Rectangle rectangle = new Rectangle(4, 6);
        rectangle.draw();
        rectangle.displayArea();
        System.out.println("Area of Rectangle: " + rectangle.calculateArea());
    }
}