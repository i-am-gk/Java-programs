// Abstract class
abstract class Shape {
    // Abstract method
    abstract void draw();
    // Concrete method
    void displayArea() {
        System.out.println("This method is common to all shapes.");
    }
}