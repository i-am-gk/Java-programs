// Concrete subclass 2
class Rectangle extends Shape {
    int length, width;
    Rectangle(int length, int width) {
        this.length = length;
        this.width = width;
    }

    // Implementation of the abstract method
    void draw() {
        System.out.println("Drawing a rectangle");
    }

    // Additional method specific to Rectangle
    int calculateArea() {
        return length * width;
    }
}
