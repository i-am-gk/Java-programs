import java.io.File;
import java.io.IOException;
public class Main {
public static void main(String[] args) {
	try {
File obj = new File("C:\\Users\\vines\\Desktop\\file1.txt");

if(obj.createNewFile()) {
	System.out.println("File created");
}
else {
	System.out.println("File already exist");

}
	}
	catch(IOException e) {
System.out.println("Error"+e.getMessage());
	}

}

}
