
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person[] people = new Person[3];
        // Initialize each element with a Person object
		// people is an array
        people[0] = new Person("Ghani",153);
        people[1] = new Person("GK",110);
        people[2] = new Person("GKD",32);
        // Access and print the names
        for (int i = 0; i < people.length; i++) {
            Person person = people[i];
            System.out.println(person.getName()+" "+person.getID());
           
        }
        }
}
