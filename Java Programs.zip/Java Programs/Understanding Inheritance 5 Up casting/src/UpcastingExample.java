
public class UpcastingExample {
	 public static void main(String[] args) {
	// Upcasting: Creating a Dog object and assigning it to an Animal reference
	        Animal animal = new Dog();
	        // Calling the overridden method in Dog class
	        animal.sound(); // Output: Dog barks
	    // Uncommenting the line below will result in a compilation error,
	    // because the reference type (Animal) does not have a fetch() method.
	   // animal.fetch(); // Compilation error
	    // Downcasting: Casting the reference back to Dog to access specific methods
	    // Dog dog = (Dog) animal;
	     //dog.fetch(); // Output: Dog fetches a ball
	  Dog animal1 = (Dog) animal;
	        animal1.fetch();
	 }
	 
	 
}
