class Car extends Vehicle {
    int numPassengers;
    Car(String licensePlate, String type, int numPassengers) {
       super (licensePlate,type);
        this.numPassengers = numPassengers;
    }
    public int getNumPassengers() {
    	return numPassengers;
    }
    public void setNumPassengers(int numPassengers) {
    	this.numPassengers=numPassengers;
    }
    @Override
    double calculateToll() {
        return 2.0 * numPassengers;
    }
}