// Implementation of TollCollector interface
import java.util.ArrayList;
class TollBooth implements TollCollector {
    private ArrayList<Vehicle> vehicles;
    // Constructor
    TollBooth() {
        this.vehicles = new ArrayList<>();
    }
    // Method to collect toll for a given vehicle
    @Override
    public void collectToll(Vehicle vehicle) {
     double tollAmount = vehicle.calculateToll();
 System.out.println("Details\nToll is calculated for " + vehicle.type + 
"\nLicense plate " + vehicle.licensePlate +
   "\nToll Amount " + tollAmount);
    }
    // Method to add a vehicle to the toll booth
    void addVehicle(Vehicle vehicle) {
        vehicles.add(vehicle);
    }
    // Method to simulate toll collection for all vehicles in the toll booth
    void collectTollForAll() {
        for (Vehicle vehicle : vehicles) {
            collectToll(vehicle);
        }
    }
}