import java.util.ArrayList;
import java.util.Random;
public class TollPlazaManagementSystem {
    public static void main(String[] args) {
        // Create instances of Car and Truck
Car car = new Car("GKD007","Car", 3);
Truck truck = new Truck("JKL330","Truck", 400.0);
        // Create a TollBooth
        TollBooth tollBooth = new TollBooth();
        // Add vehicles to the toll booth
        tollBooth.addVehicle(car);
        tollBooth.addVehicle(truck);
      // Generate a random number between 1 and 3
     Random random = new Random();
     int randomNum = random.nextInt(3) + 1;
        // If the random number is 1, place the first object at the first index
     if (randomNum == 1 ) {
      //&& tollBooth.collectTollForAll() > 0
       System.out.println("The first vehicle is placed at the first index");
       tollBooth.collectToll(car);    
     }
     else  {
         //&& tollBooth.collectTollForAll() > 0
          System.out.println("The vehicle is placed at the Second index.");
          tollBooth.collectToll(truck);    
          }
     
    }
}