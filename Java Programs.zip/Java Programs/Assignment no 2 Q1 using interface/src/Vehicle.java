// Abstract Base Class - Vehicle
public abstract class Vehicle {
    String licensePlate;
    String type;
    Vehicle(String licensePlate, String type){
    	this.licensePlate=licensePlate;
    	this.type=type;
    }
    public String getLicensePlate() {
    	return licensePlate;
    }
    public void setLicensePlate(String licensePlate) {
    	this.licensePlate=licensePlate;
    }
    public String getType() {
    	return type;
    }
    public void setType(String type) {
    	this.type=type;
    }
    // Abstract method to calculate toll
    abstract double calculateToll();
}