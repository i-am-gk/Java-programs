// Subclass 2 - Truck
class Truck extends Vehicle {
    double cargoWeight;
    Truck(String licensePlate, String type, double cargoWeight) {
    	super (licensePlate,type);
        this.cargoWeight = cargoWeight;
    }
    @Override
    double calculateToll() {
        return 10.0 * cargoWeight;
    }
}
//Interface - TollCollector
interface TollCollector {
 void collectToll(Vehicle vehicle);
}
