import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int product=1;
		int [] array = new int [5];
		Scanner scanner = new Scanner (System.in);
		System.out.println("Input 5 positive numbers");
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter value "+(i+1));
			array[i]=scanner.nextInt();
			sum+=array[i];
			product*=array[i];
		}
		System.out.println("Values are ");
		for(int i=0;i<5;i++)
		{
			System.out.println("Index " +i+ " Value "+array[i]);
		}
		System.out.println("Sum is "+sum);
		System.out.println("Product is "+product);
			}
	

}
