
public class Loop {
public void display()
{
	System.out.println("Use of loop");
	int i=0;
	do {
		System.out.println("Loop Runs Six time");
		i++;
	}
	while(i<=5);
	}
}
