import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] array = new int [5];
Scanner scanner = new Scanner (System.in);
System.out.println("Input 5 positive numbers");
for(int i=0;i<5;i++)
{
	System.out.println("Enter value "+(i+1));
	array[i]=scanner.nextInt();
}
System.out.println("Values are ");
for(int i=0;i<5;i++)
{
	System.out.println("Index " +i+ " Value "+array[i]);
}
	}

}
