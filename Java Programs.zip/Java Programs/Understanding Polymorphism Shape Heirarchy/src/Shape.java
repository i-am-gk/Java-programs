// Shape class (abstract base class)
public abstract class Shape {
    public abstract String getName();
}