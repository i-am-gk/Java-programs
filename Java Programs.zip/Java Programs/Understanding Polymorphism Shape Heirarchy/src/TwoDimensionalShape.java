// TwoDimensionalShape class (inherits from Shape)
public abstract class TwoDimensionalShape extends Shape {
    public abstract double getArea();

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
