public class HotDogStand {
	// Instance Variables
    private int id; // Hot Dog Stand ID
    private int hotDogsSold; // Number of hot dogs sold
    // Constructor to initialize both ID and hot dogs sold
    public HotDogStand(int id, int initialHotDogsSold) {
        this.id = id;
        hotDogsSold = initialHotDogsSold;
    }
    // Method to increment the number of hot dogs sold
    public void justSold() {
        hotDogsSold++;
    }
    // Getter method to retrieve the number of hot dogs sold
    public int getHotDogsSold() {
        return hotDogsSold;
}
    public int getID()
    {
    	return id;
    }
   
}
