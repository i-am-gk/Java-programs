public class Main {
	public static void main(String[] args) {
        // Create three hot dog stands
        HotDogStand stand1 = new HotDogStand(1, 5);
        HotDogStand stand2 = new HotDogStand(2, 0);
        HotDogStand stand3 = new HotDogStand(3, 7);
        // Simulate hot dog sales
        stand1.justSold();
        stand2.justSold();
        stand3.justSold();
// Display the number of hot dogs sold by each stand
System.out.println("Hot Dog Stand " + stand1.getID() + " sold " + stand1.getHotDogsSold() + " hot dogs.");
System.out.println("Hot Dog Stand " + stand2.getID() + " sold " + stand2.getHotDogsSold() + " hot dogs.");
System.out.println("Hot Dog Stand " + stand3.getID()+ " sold " + stand3.getHotDogsSold() + " hot dogs.");
    }
}
