
public class Number {
	public  int square( int intValue )
	{
	System.out.printf( "\nCalled square with int argument: %d\n",
	intValue );
	return intValue * intValue;
	} // end method square with int argument
	// square method with double argument
	public double square( double doubleValue )
	{
	System.out.printf( "\nCalled square with double argument: %f\n",
	doubleValue );
	return doubleValue * doubleValue;
	} // end method square with double argument

}
