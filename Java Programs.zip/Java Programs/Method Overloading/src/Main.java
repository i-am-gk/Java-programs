
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		double d=3.0;
		Number no = new Number();
		System.out.println("Method overloading of two methods");
		System.out.println("First method "+no.square(n));
		System.out.println("Second method "+no.square(d));
	}

}