
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student originalStudent = new Student("Alice", 20);
        // Creating a new student object by using the copy constructor
        Student copiedStudent = new Student(originalStudent);
        // Displaying the original student's details
        System.out.println("Original Student:");
        originalStudent.display();
        System.out.println();
        // Displaying the copied student's details
        System.out.println("Copied Student:");
        copiedStudent.display();
	}

}
