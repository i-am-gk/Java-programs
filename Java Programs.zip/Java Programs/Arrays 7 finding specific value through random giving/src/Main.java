
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array = new int [5];
		int value=3;
		for(int i=0;i<5;i++)
		{
			array[i]= (int)(Math.random()*10);
		}
		for(int i=0;i<5;i++)
		{
			System.out.println("Array Index "+i+"  Array Value "+array[i]);
		}
		for(int i=0;i<5;i++)
		{
			if(value==array[i])
			{
				System.out.println("Value found at index "+i);
			}
		}
			}
	
}
