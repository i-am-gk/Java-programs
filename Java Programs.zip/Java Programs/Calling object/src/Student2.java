// method 2
// initialization through method
public class Student2 {
int rollno;
String name;
void insertRecord(int r,String n) {
	rollno=r;
	name=n;
}
void displayinformation() {
	System.out.println(rollno+ "  "+name);
}
}
