public class ComplexNumber {
	 // Data Members
    private double real;
    private double imaginary;
    // No-parameter constructor
    public ComplexNumber() {
        real = 0.0;
        imaginary = 0.0;
    }
    // Parameterized constructor
    public ComplexNumber(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }
    // Copy constructor
    public ComplexNumber(ComplexNumber other) {
        real = other.real;
        imaginary = other.imaginary;
    }
    // Getter and Setter methods for the real part
    public double getReal() {
        return real;
    }
    public void setReal(double real) {
        this.real = real;
    }
    // Getter and Setter methods for the imaginary part
    public double getImaginary() {
        return imaginary;
    }
    public void setImaginary(double imaginary) {
        this.imaginary = imaginary;
    }
    // Method to add two complex numbers
    public ComplexNumber add(ComplexNumber other) {
        double rReal = real + other.real;
        double rImaginary = imaginary + other.imaginary;
        return new ComplexNumber(rReal, rImaginary);
    }
    // Method to multiply two complex numbers
    public ComplexNumber multiply(ComplexNumber other) {
        double rReal = real * other.real - imaginary * other.imaginary;
        double rImaginary = real * other.imaginary + imaginary * other.real;
        return new ComplexNumber(rReal, rImaginary);
    }
    // Method to calculate the conjugate of a complex number
    public ComplexNumber conjugate() {
        return new ComplexNumber(real, -imaginary);
    }
    public String toString() {
        if (imaginary >= 0) {
            return real + " + " + imaginary + "i";
        } else 
        {
            return real + " - " + (-imaginary) + "i";
        }
    }
}
/*The purpose of the toString method is to provide a human-readable
 *  representation of the object as a string. In your case, it converts
 *   a ComplexNumber object into a string representation in the format
 *    "a + bi" or "a - bi," depending on the sign of the imaginary part.
 */