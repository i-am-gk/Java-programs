public class Main {
	  public static void main(String[] args) {
	        ComplexNumber complex1 = new ComplexNumber(5.0, 6.0);
	        ComplexNumber complex2 = new ComplexNumber(3.0, 5.0);
	        System.out.println("Complex 1: " + complex1);
	        System.out.println("Complex 2: " + complex2);
	        ComplexNumber sum = complex1.add(complex2);
	        ComplexNumber product = complex1.multiply(complex2);
	        ComplexNumber conjugate = complex1.conjugate();
	        System.out.println("Sum: " + sum);
	        System.out.println("Product: " + product);
	        System.out.println("Conjugate: " + conjugate);
	    }
}