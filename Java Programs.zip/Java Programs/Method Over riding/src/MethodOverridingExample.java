
public class MethodOverridingExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal myAnimal = new Animal();
        Animal myDog = new Dog(); // Polymorphism: a Dog object as an Animal reference
        myAnimal.makeSound(); // Calls the Animal's makeSound method
        myDog.makeSound();     // Calls the Dog's overridden makeSound method
	}

}
