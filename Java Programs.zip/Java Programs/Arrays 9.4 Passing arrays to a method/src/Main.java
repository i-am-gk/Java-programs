
public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] numbers = {1, 2, 3, 4, 5};
        // Create an instance of the ArrayModifier class
        ArrayModifier arrayModifier = new ArrayModifier();
        System.out.println("Orignial Array");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
      // Call the modifyArray method to modify the array
        arrayModifier.modifyArray(numbers);
        // Print the modified array
        System.out.println("Modified Array:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
	}

}
