import java.util.Arrays;
import java.util.Scanner;
public class SortArray {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];
        // Read 10 numbers into the array
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }
        // Call the sortArray method to sort the array
        sortArray(numbers);
        // Display the sorted array
        System.out.println("Sorted Array: " + Arrays.toString(numbers));

        scanner.close();
    }

    // Method to sort an array using Arrays.sort()
    public static void sortArray(int[] arr) {
        Arrays.sort(arr);
	}

}
