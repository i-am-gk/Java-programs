
public class Test2 {
public void modifyarray(int [] arr)
{
	for(int i=0;i<arr.length;i++)
	{
		arr[i]=i*2;
	}
}
}
