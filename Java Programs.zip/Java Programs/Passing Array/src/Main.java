public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] array = new int [5];
Test2 t = new Test2();
System.out.println("array before passing");
for(int i=0;i<array.length;i++)
{
	System.out.println(array[i]);
}
t.modifyarray(array);
System.out.println("array after passing");
for(int i=0;i<array.length;i++)
{
	System.out.println(array[i]);
}
	}
	// do check for passing a single element

}
